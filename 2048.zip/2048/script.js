/* 2048 Glass Edition
   Fully playable 2048 clone with responsive UI, swipe support, undo, autoplay, leaderboard, and sound effects.
*/

const STORAGE_KEYS = {
  bestScore: 'game2048-best-score',
  leaderboard: 'game2048-leaderboard',
  theme: 'game2048-theme',
  settings: 'game2048-settings',
};

const audioContext = new (window.AudioContext || window.webkitAudioContext)();

class Game2048 {
  constructor() {
    this.boardGrid = document.getElementById('boardGrid');
    this.tileLayer = document.getElementById('tileLayer');
    this.scoreEl = document.getElementById('score');
    this.bestScoreEl = document.getElementById('best-score');
    this.moveCountEl = document.getElementById('moveCount');
    this.timerEl = document.getElementById('timer');
    this.statusMessage = document.getElementById('statusMessage');
    this.difficultyLabel = document.getElementById('difficultyLabel');
    this.leaderboardList = document.getElementById('leaderboardList');
    this.messageOverlay = document.getElementById('messageOverlay');
    this.overlayTitle = document.getElementById('overlayTitle');
    this.overlayText = document.getElementById('overlayText');
    this.overlayButton = document.getElementById('overlayButton');
    this.newGameBtn = document.getElementById('newGameBtn');
    this.undoBtn = document.getElementById('undoBtn');
    this.autoPlayBtn = document.getElementById('autoPlayBtn');
    this.themeBtn = document.getElementById('themeBtn');
    this.sizeSelect = document.getElementById('sizeSelect');
    this.targetSelect = document.getElementById('targetSelect');

    this.tileMap = new Map();
    this.state = null;
    this.autoTimer = null;
    this.moveStart = null;
    this.pressedKeys = new Set();

    this.loadPreferences();
    this.attachEventHandlers();
    this.setTheme(this.theme);
    this.beginNewGame();
  }

  loadPreferences() {
    const savedTheme = localStorage.getItem(STORAGE_KEYS.theme);
    this.theme = savedTheme || 'theme-dark';
    const savedSettings = JSON.parse(localStorage.getItem(STORAGE_KEYS.settings) || '{}');
    this.defaultSize = savedSettings.size || 4;
    this.defaultTarget = savedSettings.target || 2048;
    this.sizeSelect.value = this.defaultSize;
    this.targetSelect.value = this.defaultTarget;
  }

  savePreferences() {
    localStorage.setItem(STORAGE_KEYS.theme, this.theme);
    localStorage.setItem(STORAGE_KEYS.settings, JSON.stringify({
      size: this.state.size,
      target: this.state.targetValue,
    }));
  }

  attachEventHandlers() {
    this.newGameBtn.addEventListener('click', () => this.beginNewGame());
    this.undoBtn.addEventListener('click', () => this.undoMove());
    this.autoPlayBtn.addEventListener('click', () => this.toggleAutoPlay());
    this.themeBtn.addEventListener('click', () => this.toggleTheme());
    this.overlayButton.addEventListener('click', () => this.beginNewGame());
    this.sizeSelect.addEventListener('change', () => this.beginNewGame());
    this.targetSelect.addEventListener('change', () => this.beginNewGame());

    window.addEventListener('keydown', (event) => this.handleKeyDown(event));
    window.addEventListener('keyup', (event) => this.pressedKeys.delete(event.key));
    window.addEventListener('resize', () => this.render());

    this.boardGrid.addEventListener('pointerdown', (event) => this.handlePointerDown(event));
    this.boardGrid.addEventListener('pointerup', (event) => this.handlePointerUp(event));
    this.boardGrid.addEventListener('pointercancel', () => (this.moveStart = null));
    this.boardGrid.addEventListener('contextmenu', (event) => event.preventDefault());
  }

  beginNewGame() {
    this.stopAutoPlay();
    const size = Number(this.sizeSelect.value) || 4;
    const targetValue = Number(this.targetSelect.value) || 2048;
    this.state = {
      size,
      targetValue,
      tiles: [],
      score: 0,
      moves: 0,
      elapsedSeconds: 0,
      isGameOver: false,
      isWin: false,
      undoStack: [],
    };

    this.moveCountEl.textContent = '0';
    this.scoreEl.textContent = '0';
    this.updateDifficultyLabel();
    this.buildBoardGrid();
    this.clearTiles();
    this.addRandomTile();
    this.addRandomTile();
    this.state.undoStack = [];
    this.updateLeaderboard();
    this.updateButtonStates();
    this.resetTimer();
    this.savePreferences();
    this.hideOverlay();
    this.setMessage('Use arrow keys or swipe to move.');
  }

  updateDifficultyLabel() {
    const sizeText = this.state.size === 4 ? 'Easy' : this.state.size === 5 ? 'Medium' : 'Hard';
    this.difficultyLabel.textContent = `${sizeText} (${this.state.size}×${this.state.size})`;
  }

  buildBoardGrid() {
    this.boardGrid.innerHTML = '';
    this.boardGrid.style.gridTemplateColumns = `repeat(${this.state.size}, minmax(0, 1fr))`;
    for (let i = 0; i < this.state.size * this.state.size; i++) {
      const cell = document.createElement('div');
      cell.className = 'cell';
      cell.setAttribute('aria-hidden', 'true');
      this.boardGrid.appendChild(cell);
    }
  }

  getEmptyCells() {
    const empty = [];
    for (let row = 0; row < this.state.size; row++) {
      for (let col = 0; col < this.state.size; col++) {
        if (!this.getTile(row, col)) {
          empty.push({ row, col });
        }
      }
    }
    return empty;
  }

  getTile(row, col) {
    return this.state.tiles.find((tile) => tile.row === row && tile.col === col) || null;
  }

  addRandomTile() {
    const emptyCells = this.getEmptyCells();
    if (!emptyCells.length) return;
    const { row, col } = emptyCells[Math.floor(Math.random() * emptyCells.length)];
    const value = Math.random() < 0.9 ? 2 : 4;
    const tile = {
      id: this.generateId(),
      row,
      col,
      value,
      isNew: true,
      merged: false,
    };
    this.state.tiles.push(tile);
    this.playSound('spawn');
    this.render();
  }

  generateId() {
    this.tileCounter = (this.tileCounter || 0) + 1;
    return `tile-${Date.now()}-${this.tileCounter}`;
  }

  clearTiles() {
    this.tileLayer.innerHTML = '';
    this.tileMap.clear();
    this.state.tiles = [];
  }

  handleKeyDown(event) {
    if (event.repeat) return;
    const directions = {
      ArrowUp: 'up',
      ArrowDown: 'down',
      ArrowLeft: 'left',
      ArrowRight: 'right',
      w: 'up',
      s: 'down',
      a: 'left',
      d: 'right',
    };
    const direction = directions[event.key];
    if (direction) {
      event.preventDefault();
      this.handleMove(direction);
    }
  }

  handlePointerDown(event) {
    this.moveStart = { x: event.clientX, y: event.clientY };
  }

  handlePointerUp(event) {
    if (!this.moveStart) return;
    const dx = event.clientX - this.moveStart.x;
    const dy = event.clientY - this.moveStart.y;
    const absX = Math.abs(dx);
    const absY = Math.abs(dy);
    const threshold = 30;
    if (Math.max(absX, absY) > threshold) {
      const direction = absX > absY ? (dx > 0 ? 'right' : 'left') : dy > 0 ? 'down' : 'up';
      this.handleMove(direction);
    }
    this.moveStart = null;
  }

  handleMove(direction) {
    if (this.state.isGameOver || this.state.isWin) return;
    this.initAudio();
    this.saveUndoState();
    const moved = this.move(direction);
    if (!moved) {
      this.state.undoStack.pop();
      return;
    }
    this.state.moves += 1;
    this.updateMoveCount();
    this.adjustScore(this.state.score);
    this.addRandomTile();
    this.updateButtonStates();
    if (this.checkGameOver()) {
      this.showGameOver();
    } else if (this.state.isWin) {
      this.showWinMessage();
    } else {
      this.setMessage('Keep going, you are doing great.');
    }
  }

  saveUndoState() {
    const snapshot = {
      tiles: this.state.tiles.map((tile) => ({ ...tile })),
      score: this.state.score,
      moves: this.state.moves,
      elapsedSeconds: this.state.elapsedSeconds,
      isWin: this.state.isWin,
      isGameOver: this.state.isGameOver,
    };
    this.state.undoStack.push(snapshot);
    if (this.state.undoStack.length > 6) this.state.undoStack.shift();
  }

  undoMove() {
    if (!this.state.undoStack.length) return;
    const previous = this.state.undoStack.pop();
    this.state.tiles = previous.tiles.map((tile) => ({ ...tile, isNew: false, merged: false }));
    this.state.score = previous.score;
    this.state.moves = previous.moves;
    this.state.elapsedSeconds = previous.elapsedSeconds;
    this.state.isWin = previous.isWin;
    this.state.isGameOver = previous.isGameOver;
    this.updateScoreDisplay();
    this.updateMoveCount();
    this.render();
    this.updateButtonStates();
    this.setMessage('Undo applied, try a different strategy.');
  }

  move(direction) {
    const vector = this.getVector(direction);
    const traversals = this.buildTraversals(vector);
    let moved = false;
    this.prepareTiles();

    traversals.x.forEach((x) => {
      traversals.y.forEach((y) => {
        const tile = this.getTile(y, x);
        if (!tile) return;

        const positions = this.findFarthestPosition({ row: y, col: x }, vector);
        const nextTile = this.getTile(positions.next.row, positions.next.col);

        if (nextTile && nextTile.value === tile.value && !nextTile.merged) {
          const mergedTile = {
            id: tile.id,
            row: positions.next.row,
            col: positions.next.col,
            value: tile.value * 2,
            merged: true,
            isNew: false,
          };
          this.state.tiles = this.state.tiles.filter((item) => item !== tile && item !== nextTile);
          this.state.tiles.push(mergedTile);
          this.playSound('merge');
          this.createParticles(mergedTile.row, mergedTile.col);
          this.state.score += mergedTile.value;
          moved = true;
          if (mergedTile.value === this.state.targetValue) {
            this.state.isWin = true;
          }
        } else {
          if (positions.farthest.row !== y || positions.farthest.col !== x) {
            tile.row = positions.farthest.row;
            tile.col = positions.farthest.col;
            moved = true;
          }
        }
      });
    });

    if (moved) {
      this.playSound('move');
      this.render();
      return true;
    }
    return false;
  }

  prepareTiles() {
    this.state.tiles.forEach((tile) => {
      tile.merged = false;
      tile.isNew = false;
    });
  }

  getVector(direction) {
    const map = {
      up: { row: -1, col: 0 },
      down: { row: 1, col: 0 },
      left: { row: 0, col: -1 },
      right: { row: 0, col: 1 },
    };
    return map[direction];
  }

  buildTraversals(vector) {
    const traversals = { x: [], y: [] };
    for (let pos = 0; pos < this.state.size; pos += 1) {
      traversals.x.push(pos);
      traversals.y.push(pos);
    }
    if (vector.col === 1) traversals.x.reverse();
    if (vector.row === 1) traversals.y.reverse();
    return traversals;
  }

  findFarthestPosition(start, vector) {
    let previous;
    let current = { ...start };
    do {
      previous = { ...current };
      current = { row: previous.row + vector.row, col: previous.col + vector.col };
    } while (this.withinBounds(current) && !this.getTile(current.row, current.col));
    return {
      farthest: previous,
      next: current,
    };
  }

  withinBounds(position) {
    return (
      position.row >= 0 && position.row < this.state.size &&
      position.col >= 0 && position.col < this.state.size
    );
  }

  checkGameOver() {
    if (this.state.tiles.length === 0) return false;
    if (this.getEmptyCells().length > 0) return false;
    for (let row = 0; row < this.state.size; row += 1) {
      for (let col = 0; col < this.state.size; col += 1) {
        const tile = this.getTile(row, col);
        if (!tile) continue;
        const neighbors = [
          { row: row - 1, col },
          { row: row + 1, col },
          { row, col: col - 1 },
          { row, col: col + 1 },
        ];
        for (const pos of neighbors) {
          const neighbor = this.getTile(pos.row, pos.col);
          if (neighbor && neighbor.value === tile.value) return false;
        }
      }
    }
    this.state.isGameOver = true;
    return true;
  }

  showGameOver() {
    this.saveLeaderboardEntry();
    this.updateLeaderboard();
    this.setMessage('No more moves. Try again or use undo.');
    this.showOverlay('Game Over', 'Your score has been recorded. Press Play Again to start a fresh board.');
    this.playSound('lose');
  }

  showWinMessage() {
    this.saveLeaderboardEntry();
    this.updateLeaderboard();
    this.setMessage('Congratulations! You reached your target.');
    this.showOverlay('You Win!', 'You reached the target tile. Continue playing or restart for a new challenge.');
    this.playSound('win');
  }

  showOverlay(title, text) {
    this.overlayTitle.textContent = title;
    this.overlayText.textContent = text;
    this.messageOverlay.classList.remove('hidden');
  }

  hideOverlay() {
    this.messageOverlay.classList.add('hidden');
  }

  updateButtonStates() {
    this.undoBtn.disabled = !this.state.undoStack.length;
    if (this.autoTimer) {
      this.autoPlayBtn.textContent = 'Stop Autoplay';
    } else {
      this.autoPlayBtn.textContent = 'AI Autoplay';
    }
  }

  adjustScore(newScore) {
    this.state.score = newScore;
    const bestScore = Number(localStorage.getItem(STORAGE_KEYS.bestScore) || 0);
    if (this.state.score > bestScore) {
      localStorage.setItem(STORAGE_KEYS.bestScore, String(this.state.score));
    }
    this.updateScoreDisplay();
  }

  updateScoreDisplay() {
    const bestScore = Number(localStorage.getItem(STORAGE_KEYS.bestScore) || 0);
    this.scoreEl.textContent = String(this.state.score);
    this.bestScoreEl.textContent = String(Math.max(bestScore, this.state.score));
  }

  updateMoveCount() {
    this.moveCountEl.textContent = String(this.state.moves);
  }

  setMessage(message) {
    this.statusMessage.textContent = message;
  }

  render() {
    this.updateScoreDisplay();
    this.updateMoveCount();
    this.updateBoardState();
  }

  updateBoardState() {
    const boardRect = this.boardGrid.getBoundingClientRect();
    const gap = 14;
    const cellSize = (boardRect.width - gap * (this.state.size + 1)) / this.state.size;
    const tileSize = Math.max(0, cellSize);

    const existingIds = new Set();
    this.state.tiles.forEach((tile) => {
      const tileEl = this.tileMap.get(tile.id) || this.createTileElement(tile);
      existingIds.add(tile.id);
      tileEl.className = `tile value-${tile.value}`;
      tileEl.dataset.value = String(tile.value);
      tileEl.setAttribute('aria-label', `Tile ${tile.value}`);
      tileEl.style.width = `${tileSize}px`;
      tileEl.style.height = `${tileSize}px`;
      tileEl.style.left = `${gap + tile.col * (tileSize + gap)}px`;
      tileEl.style.top = `${gap + tile.row * (tileSize + gap)}px`;
      tileEl.style.fontSize = tile.value > 999 ? '1.1rem' : '1.5rem';
      tileEl.querySelector('span').textContent = tile.value;

      tileEl.classList.toggle('tile-new', Boolean(tile.isNew));
      tileEl.classList.toggle('tile-merged', Boolean(tile.merged));

      if (tile.isNew) {
        tile.isNew = false;
      }
    });

    for (const [tileId, tileEl] of this.tileMap.entries()) {
      if (!existingIds.has(tileId)) {
        tileEl.remove();
        this.tileMap.delete(tileId);
      }
    }
  }

  createTileElement(tile) {
    const tileEl = document.createElement('div');
    tileEl.className = `tile value-${tile.value}`;
    tileEl.dataset.id = tile.id;
    tileEl.innerHTML = `<span>${tile.value}</span>`;
    this.tileLayer.appendChild(tileEl);
    this.tileMap.set(tile.id, tileEl);
    return tileEl;
  }

  initAudio() {
    if (audioContext.state === 'suspended') {
      audioContext.resume().catch(() => {});
    }
  }

  playSound(type) {
    if (!audioContext) return;
    const duration = 0.08;
    const now = audioContext.currentTime;
    const gain = audioContext.createGain();
    const oscillator = audioContext.createOscillator();
    oscillator.type = 'sine';
    gain.gain.setValueAtTime(0.08, now);
    if (type === 'merge') {
      oscillator.frequency.setValueAtTime(280, now);
      gain.gain.exponentialRampToValueAtTime(0.003, now + duration);
    } else if (type === 'win') {
      oscillator.frequency.setValueAtTime(520, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.16);
    } else if (type === 'lose') {
      oscillator.frequency.setValueAtTime(120, now);
      gain.gain.exponentialRampToValueAtTime(0.002, now + duration);
    } else {
      oscillator.frequency.setValueAtTime(180, now);
      gain.gain.exponentialRampToValueAtTime(0.003, now + duration);
    }
    oscillator.connect(gain).connect(audioContext.destination);
    oscillator.start(now);
    oscillator.stop(now + duration);
  }

  toggleAutoPlay() {
    if (this.autoTimer) {
      this.stopAutoPlay();
      this.setMessage('Autoplay stopped.');
      return;
    }
    this.initAudio();
    this.setMessage('AI autopilot started. Watching moves now.');
    this.autoTimer = setInterval(() => {
      const next = this.chooseBestAIMove();
      if (!next) {
        this.stopAutoPlay();
        return;
      }
      this.handleMove(next);
      if (this.state.isGameOver || this.state.isWin) {
        this.stopAutoPlay();
      }
    }, 260);
    this.updateButtonStates();
  }

  stopAutoPlay() {
    if (this.autoTimer) {
      clearInterval(this.autoTimer);
      this.autoTimer = null;
      this.updateButtonStates();
    }
  }

  chooseBestAIMove() {
    const directions = ['up', 'left', 'right', 'down'];
    let best = null;
    let bestScore = -Infinity;
    for (const direction of directions) {
      const snapshot = this.cloneState();
      const moved = this.simulateMove(direction);
      if (!moved) {
        this.restoreState(snapshot);
        continue;
      }
      const score = this.state.score + this.state.tiles.length * 0.1;
      if (score > bestScore) {
        bestScore = score;
        best = direction;
      }
      this.restoreState(snapshot);
    }
    return best;
  }

  simulateMove(direction) {
    const vector = this.getVector(direction);
    const traversals = this.buildTraversals(vector);
    let moved = false;
    const duplicate = this.state.tiles.map((tile) => ({ ...tile }));
    traversals.x.forEach((x) => {
      traversals.y.forEach((y) => {
        const tile = duplicate.find((item) => item.row === y && item.col === x);
        if (!tile) return;
        let current = { row: y, col: x };
        let next = { row: current.row + vector.row, col: current.col + vector.col };
        while (this.withinBounds(next) && !duplicate.find((item) => item.row === next.row && item.col === next.col)) {
          current = { ...next };
          next = { row: current.row + vector.row, col: current.col + vector.col };
        }
        const nextTile = duplicate.find((item) => item.row === next.row && item.col === next.col);
        if (nextTile && nextTile.value === tile.value && !nextTile.merged) {
          nextTile.value *= 2;
          nextTile.merged = true;
          duplicate.splice(duplicate.indexOf(tile), 1);
          moved = true;
        } else if (current.row !== y || current.col !== x) {
          tile.row = current.row;
          tile.col = current.col;
          moved = true;
        }
      });
    });
    return moved;
  }

  cloneState() {
    return {
      tiles: this.state.tiles.map((tile) => ({ ...tile })),
      score: this.state.score,
      moves: this.state.moves,
      elapsedSeconds: this.state.elapsedSeconds,
      isWin: this.state.isWin,
      isGameOver: this.state.isGameOver,
    };
  }

  restoreState(snapshot) {
    this.state.tiles = snapshot.tiles.map((tile) => ({ ...tile }));
    this.state.score = snapshot.score;
    this.state.moves = snapshot.moves;
    this.state.elapsedSeconds = snapshot.elapsedSeconds;
    this.state.isWin = snapshot.isWin;
    this.state.isGameOver = snapshot.isGameOver;
  }

  saveLeaderboardEntry() {
    const leaderboard = JSON.parse(localStorage.getItem(STORAGE_KEYS.leaderboard) || '[]');
    leaderboard.push({
      score: this.state.score,
      moves: this.state.moves,
      target: this.state.targetValue,
      date: new Date().toLocaleDateString(),
    });
    leaderboard.sort((a, b) => b.score - a.score || a.moves - b.moves);
    localStorage.setItem(STORAGE_KEYS.leaderboard, JSON.stringify(leaderboard.slice(0, 6)));
  }

  updateLeaderboard() {
    const leaderboard = JSON.parse(localStorage.getItem(STORAGE_KEYS.leaderboard) || '[]');
    this.leaderboardList.innerHTML = leaderboard.length
      ? leaderboard
          .slice(0, 5)
          .map(
            (entry) =>
              `<li><span>${entry.date}</span><strong>${entry.score}</strong><span>${entry.moves} moves</span></li>`
          )
          .join('')
      : '<li>No leaderboard entries yet.</li>';
  }

  toggleTheme() {
    this.theme = this.theme === 'theme-dark' ? 'theme-glass' : 'theme-dark';
    this.setTheme(this.theme);
    this.savePreferences();
  }

  setTheme(theme) {
    document.body.classList.remove('theme-dark', 'theme-glass');
    document.body.classList.add(theme);
  }

  resetTimer() {
    this.state.elapsedSeconds = 0;
    clearInterval(this.timerInterval);
    this.timerEl.textContent = '00:00';
    this.timerInterval = setInterval(() => {
      if (this.state.isGameOver || this.state.isWin) return;
      this.state.elapsedSeconds += 1;
      this.timerEl.textContent = this.formatTime(this.state.elapsedSeconds);
    }, 1000);
  }

  formatTime(seconds) {
    const minutes = String(Math.floor(seconds / 60)).padStart(2, '0');
    const secs = String(seconds % 60).padStart(2, '0');
    return `${minutes}:${secs}`;
  }

  createParticles(row, col) {
    const boardRect = this.boardGrid.getBoundingClientRect();
    const gap = 14;
    const cellSize = (boardRect.width - gap * (this.state.size + 1)) / this.state.size;
    const centerX = gap + col * (cellSize + gap) + cellSize / 2;
    const centerY = gap + row * (cellSize + gap) + cellSize / 2;
    for (let i = 0; i < 11; i += 1) {
      const particle = document.createElement('span');
      particle.className = 'particle';
      const angle = Math.random() * Math.PI * 2;
      const distance = 26 + Math.random() * 18;
      particle.style.setProperty('--dx', `${Math.cos(angle) * distance}px`);
      particle.style.setProperty('--dy', `${Math.sin(angle) * distance}px`);
      particle.style.left = `${centerX}px`;
      particle.style.top = `${centerY}px`;
      particle.style.background = `hsl(${Math.random() * 40 + 180}, 90%, 68%)`;
      this.tileLayer.appendChild(particle);
      setTimeout(() => particle.remove(), 700);
    }
  }
}

window.addEventListener('DOMContentLoaded', () => {
  new Game2048();
});
