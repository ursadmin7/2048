# 2048 Glass Edition

A polished, fully playable 2048 game built with HTML, CSS, and JavaScript.

## Run locally in Visual Studio Code

1. Open the `2048` folder in Visual Studio Code.
2. Install the **Live Server** extension if you don't already have it.
3. Open `index.html`.
4. Right-click anywhere in the editor and choose **Open with Live Server**.

## Features

- Responsive glassmorphism / dark theme design
- Arrow key and touch swipe controls
- Smooth tile animations, merge effects, and particle bursts
- Score board, best score persistence, move counter, and timer
- Undo, autoplay bot, board size and target settings
- Leaderboard stored in `localStorage`
- Theme switching and accessible UI
